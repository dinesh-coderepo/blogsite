---
title: Learning how to build an recommendation system from initial signals
subheading: From a few initial adopters of a product, how we can target new set of users who are more likely can use the product
date: 2025-07-19
---

# Building a target system to focus on building a score for users depending on early adopters


Coming soon

