---
title: Basics of Azure AI foundry
subheading: Researching on Foundry tool kit in azure and its usecases and implementing real world projects
date: 2025-01-13
---

# Azure AI Foundry service divedeep

### Initial knowledge dump

- As part of intro,  going through the YouTube video : [youtube](https://youtu.be/nC766APIZFM?si=Vx8n4cJoQCmckgkP)
- AI foundry agent intro : [youtube](https://youtu.be/ltt7JNd30Ag?si=TUHrwTrdDgAu-2eN)
- Azure AI Foundry learning path by azure : [link](https://learn.microsoft.com/en-gb/training/paths/create-custom-copilots-ai-studio/)

### My findings and progress 

#### Continued 

