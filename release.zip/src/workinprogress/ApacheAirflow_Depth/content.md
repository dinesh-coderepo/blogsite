---
title: Apache Airflow - open source orchestration engine
subheading: Architecture of Apache Airflow, how DAGs help design complex flows and dependencies, and how we can leverage Apache airflow to train a ML Model and monitor.
date: 2025-01-08
---

# Apache Airflow - Going deep

### Coming soon..