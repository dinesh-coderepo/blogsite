---
title: Building windows app and publishing to app store.
subheading: "Exploring the fundamentals of building an .exe file from scratch, including C++ compilation, object files, linking, DLLs, and more."
date: 2025-04-28
---

# Building a windows app from scratch

```
End goal is to publish a windows app in the windows app store
```

## Coming soon...



