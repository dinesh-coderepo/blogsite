# blogsite

## Blog type site to publish articles
## AI and ML solutions

## Site : [blog](https://dineshblog.com)

```
/src/
│
├── app.py
├── templates/
│   ├── index_blog.html
│   ├── blog.html
│   └── ...
└── blog_posts/
    ├── post1/
    │   ├── content.md
    │   └── image.jpg
    ├── post2/
    │   ├── content.md
    │   └── image.png
    └── ...
```